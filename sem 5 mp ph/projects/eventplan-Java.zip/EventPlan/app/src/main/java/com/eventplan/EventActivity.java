package com.eventplan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class EventActivity extends AppCompatActivity {
    SQLiteDatabase db;
    DatabaseHelper my;
    Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);
        b=(Button)findViewById(R.id.wed);
        my = new DatabaseHelper(this);
        db = my.getReadableDatabase();

   b.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View view) {
           String message = getIntent().getStringExtra("ss");
           String message1 = getIntent().getStringExtra("ss1");
           String message2 = getIntent().getStringExtra("ss2");
           if(message2.equals("Admin")) {

               Cursor res = db.rawQuery("SELECT * FROM " + DatabaseHelper.TABLE_NAME + " WHERE " + DatabaseHelper.COL_2 + "=? AND " + DatabaseHelper.COL_4 + "=? And " + DatabaseHelper.COL_5 + "=?", new String[]{message, message1, message2});
               if (res != null) {
                   if (res.getCount() == 1) {
                       Toast.makeText(getApplicationContext(), "Admin event succesfull", Toast.LENGTH_LONG).show();
                       startActivity(new Intent(EventActivity.this, PackageActivity.class));
                       Intent i=new Intent(EventActivity.this,PackageActivity.class);
                       i.putExtra("ss3",message2);
                       startActivity(i);
                   }
               }
           }
          else if(message2.equals("Customer")) {

               Cursor res = db.rawQuery("SELECT * FROM " + DatabaseHelper.TABLE_NAME + " WHERE " + DatabaseHelper.COL_2 + "=? AND " + DatabaseHelper.COL_4 + "=? And " + DatabaseHelper.COL_5 + "=?", new String[]{message, message1, message2});
               if (res != null) {
                   if (res.getCount() == 1) {
                       Toast.makeText(getApplicationContext(), "Customer event succesfull", Toast.LENGTH_LONG).show();
                       Intent i=new Intent(EventActivity.this,PackageActivity.class);
                       i.putExtra("ss3",message2);
                       startActivity(i);
                   }
               }
           }
           else if(message2.equals("Vendor")) {

               Cursor res = db.rawQuery("SELECT * FROM " + DatabaseHelper.TABLE_NAME + " WHERE " + DatabaseHelper.COL_2 + "=? AND " + DatabaseHelper.COL_4 + "=? And " + DatabaseHelper.COL_5 + "=?", new String[]{message, message1, message2});
               if (res != null) {
                   if (res.getCount() == 1) {
                       Toast.makeText(getApplicationContext(), "Vendor event succesfull", Toast.LENGTH_LONG).show();
                       startActivity(new Intent(EventActivity.this, PackageActivity.class));
                       Intent i=new Intent(EventActivity.this,PackageActivity.class);
                       i.putExtra("ss3",message2);
                       startActivity(i);
                   }
               }
           }

           }
       });
   }
}
