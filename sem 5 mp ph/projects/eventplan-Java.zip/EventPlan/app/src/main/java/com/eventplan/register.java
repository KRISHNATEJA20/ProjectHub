package com.eventplan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.text.HtmlCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class register extends AppCompatActivity {

    DatabaseHelper my;
    EditText un;
    EditText em;
    EditText pa;
    Button b;
    TextView log;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        un = (EditText) findViewById(R.id.user1);
        em = (EditText) findViewById(R.id.email1);
        pa = (EditText) findViewById(R.id.pass1);
        b = (Button) findViewById(R.id.reg1);
        final Spinner spinner = (Spinner) findViewById(R.id.spinner2);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.planets_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        my=new DatabaseHelper(this);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean in= my.insertData(un.getText().toString(),em.getText().toString(),pa.getText().toString(),spinner.getSelectedItem().toString());
                if(in=true)
                {
                    Toast.makeText(getApplicationContext(), "User Registered Successfully", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(register.this,MainActivity.class));
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Enter Values", Toast.LENGTH_LONG).show();
                }


            }
        });
    }

}