package com.eventplan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class PackageActivity extends AppCompatActivity {

    Button p1,p2,ud;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_package);
        p1=(Button)findViewById(R.id.p1);
        p2=(Button)findViewById(R.id.p2);
        ud=(Button)findViewById(R.id.userdef);
        final String message2 = getIntent().getStringExtra("ss3");
        if(message2.equals("Customer")) {
            ud.setVisibility(View.VISIBLE);
        }
        else if(message2.equals("Admin")) {
            ud.setVisibility(View.INVISIBLE);
        }
        else if(message2.equals("Vendor")) {
            ud.setVisibility(View.INVISIBLE);
        }

        p1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(PackageActivity.this,PackOneActivity.class);
                i.putExtra("ss4",message2);
                startActivity(i);
            }
        });

    }
}
