package com.eventplan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class PackOneActivity extends AppCompatActivity {

    DatabaseHelper my;
    Button a,e,s,b,d;
    TextView t,s1,c1;
    EditText coss;
    SQLiteDatabase db;
    LinearLayout l,l2,l3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pack_one);
        a=(Button)findViewById(R.id.aadd);
        coss=(EditText) findViewById(R.id.cos);
        t=(TextView)findViewById(R.id.disview);
        s1=(TextView)findViewById(R.id.sname1);
        c1=(TextView)findViewById(R.id.cost1);
        d=(Button)findViewById(R.id.adel);
        s=(Button)findViewById(R.id.adis);
        e=(Button)findViewById(R.id.aback);
        b=(Button)findViewById(R.id.edit);
        l=(LinearLayout)findViewById(R.id.linearLayout);
        l2=(LinearLayout)findViewById(R.id.linearLayout3);
        l3=(LinearLayout)findViewById(R.id.linearLayout2);
        my = new DatabaseHelper(this);
        db = my.getReadableDatabase();
        String message2 = getIntent().getStringExtra("ss4");


        final Spinner spinner = (Spinner) findViewById(R.id.spinner4);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.pack_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        my=new DatabaseHelper(this);


        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ab=coss.getText().toString();
                String bc=spinner.getSelectedItem().toString();
                if(ab.equals("")) {
                    Toast.makeText(getApplicationContext(), "Enter Values", Toast.LENGTH_LONG).show();
                }
                else
                {
                    boolean in = my.insertData2(bc,ab);
                    if (in = true) {
                        Toast.makeText(getApplicationContext(), "User Registered Successfully", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Enter Values", Toast.LENGTH_LONG).show();
                    }
                }

            }
        });
        e.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s1.setText("");
                c1.setText("");
            }
        });
        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Integer deletedRows =  my.delData(spinner.getSelectedItem().toString());
                if(deletedRows > 0) {
                    Toast.makeText(PackOneActivity.this, "Data Deleted", Toast.LENGTH_LONG).show();

                }
                else
                    Toast.makeText(PackOneActivity.this,"Data not Found",Toast.LENGTH_LONG).show();

            }

        });
        s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                viewData();
                }
        });
        if(message2.equals("Customer")) {
            l.setVisibility(View.INVISIBLE);
            b.setVisibility(View.INVISIBLE);
            a.setVisibility(View.INVISIBLE);
            s.setVisibility(View.INVISIBLE);
            e.setVisibility(View.INVISIBLE);
            d.setVisibility(View.INVISIBLE);
            viewData();
        }
        else if(message2.equals("Admin")) {
            viewData();
        }

    }
    private void viewData()
    {
        Cursor res = db.rawQuery("SELECT distinct * FROM " + DatabaseHelper.TABLE_NAME2 , null);
        if (res != null) {
            if (res.getCount() >= 1) {
                while (res.moveToNext()) {
                    String en1 = res.getString(0 ) + "\n_____________________\n";
                    s1.append(en1);
                    String en2 = res.getString(1) + "\n______________________\n";
                    c1.append(en2);

                }
            }
        }
    }


}
