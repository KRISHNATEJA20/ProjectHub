package com.eventplan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText un,pa;
    Button l,r;
    SQLiteDatabase db;
    DatabaseHelper my;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        un=(EditText)findViewById(R.id.username);
        pa=(EditText)findViewById(R.id.password);
        l=(Button)findViewById(R.id.login);
        r=(Button)findViewById(R.id.register);
        un.setText("kush");
        pa.setText("1234");
        final Spinner spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.planets_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        my=new DatabaseHelper(this);
        db=my.getReadableDatabase();
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,register.class));
            }
        });
        l.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String uu=un.getText().toString();
                String pp=pa.getText().toString();
                String ut=spinner.getSelectedItem().toString();

                Cursor res=db.rawQuery("SELECT * FROM "+ DatabaseHelper.TABLE_NAME + " WHERE " + DatabaseHelper.COL_2+"=? AND " +DatabaseHelper.COL_4 +"=? And " + DatabaseHelper.COL_5+"=?" , new String[]{uu,pp,ut});
                if(res!=null){
                    if(res.getCount()==1){
                        Toast.makeText(getApplicationContext(),"succesfull",Toast.LENGTH_LONG).show();
                        Intent i=new Intent(MainActivity.this,EventActivity.class);
                        i.putExtra("ss",uu);
                        i.putExtra("ss1",pp);
                        i.putExtra("ss2",ut);
                        startActivity(i);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),"not succesfull",Toast.LENGTH_LONG).show();
                    }
                }

            }
        });
    }
}
