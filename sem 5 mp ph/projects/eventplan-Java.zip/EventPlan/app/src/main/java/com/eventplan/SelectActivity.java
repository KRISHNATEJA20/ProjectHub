package com.eventplan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class SelectActivity extends AppCompatActivity {

    Button a,d,s,b;
    TextView t;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select);
        a=(Button)findViewById(R.id.cadd);
        t=(TextView)findViewById(R.id.disview);
        final Spinner spinner = (Spinner) findViewById(R.id.spinner3);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.pack_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    t.append(spinner.getSelectedItem().toString()+ " \n");


            }
        });
    }
}
