package com.eventplan;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME="event.db";
    public static final String TABLE_NAME="register";
    public static final String TABLE_NAME2="slist";
    public static final String COL_1="Id";
    public static final String COL_2="username";
    public static final String COL_3="Email";
    public static final String COL_4="password";
    public static final String COL_5="u_type";

    public static final String COL_6="ser_name";
    public static final String COL_7="cost";



    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null,1);
        SQLiteDatabase db=this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + "(Id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT,Email Text,password TEXT,u_type Text)");
        db.execSQL("CREATE TABLE " + TABLE_NAME2+ "(ser_name TEXT unique not null,cost INTEGER not null)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME2);
        onCreate(db);
    }
    public boolean insertData(String username, String Email, String password,String u_type)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL_2,username);
        contentValues.put(COL_3,Email);
        contentValues.put(COL_4,password);
        contentValues.put(COL_5,u_type);
        long res = db.insert(TABLE_NAME,null,contentValues);
        if(res==-1)
            return false;
        else
            return true;
    }
    public boolean insertData2(String ser_name,String cost) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_6, ser_name);
        contentValues.put(COL_7, cost);
        long res = db.insert(TABLE_NAME2, null, contentValues);
        if (res == -1)
            return false;
        else
            return true;
    }

    public Cursor viewData()
    {
        SQLiteDatabase db=this.getReadableDatabase();
        String query="select * from slist";
        Cursor cursor=db.rawQuery(query,null);
        return cursor;
    }
    public Integer delData(String ser)
    {
        SQLiteDatabase db=this.getReadableDatabase();
          return  db.delete(TABLE_NAME2,COL_6  + "=?",new String[]{ser});
    }

}
